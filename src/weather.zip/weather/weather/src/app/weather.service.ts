import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  url;
  redditUrl;
  weirdFix;

  constructor(private http: HttpClient) {
    // way better api for weather
    // did have an issue with this api though
    // Fixed with --> https://tinyurl.com/ycr65jd9
    // https://stackoverflow.com/questions/18642828/origin-origin-is-not-allowed-by-access-control-allow-origin

    this.url = '/weather';

  }

  getWeather() {

    return this.http.get(this.url).pipe(map(result => {
      console.log(result);
      return result;
    }));
  }

}
